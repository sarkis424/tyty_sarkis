CREATE TABLE roles (
    role_id SERIAL PRIMARY KEY,
    role_name VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE users (
    user_id SERIAL PRIMARY KEY,
    last_name VARCHAR(100) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    middle_name VARCHAR(100),
    login VARCHAR(50) NOT NULL UNIQUE,
    role_id INTEGER NOT NULL,
    FOREIGN KEY (role_id) REFERENCES roles(role_id) ON DELETE RESTRICT
);

CREATE TABLE products (
    product_id SERIAL PRIMARY KEY,
    category VARCHAR(100) NOT NULL,
    subcategory VARCHAR(100) NOT NULL,
    product_name VARCHAR(255) NOT NULL,
    manufacturer VARCHAR(100) NOT NULL,
    image_path VARCHAR(255) DEFAULT 'picture.png',
    description TEXT,
    composition VARCHAR(255),
    price NUMERIC(10, 2) NOT NULL CHECK (price >= 0)
);

CREATE TABLE sizes (
    size_id SERIAL PRIMARY KEY,
    size_value VARCHAR(10) NOT NULL UNIQUE
);

CREATE TABLE stock_items (
    stock_item_id SERIAL PRIMARY KEY,
    product_id INTEGER NOT NULL,
    size_id INTEGER NOT NULL,
    quantity_available INTEGER NOT NULL DEFAULT 0 CHECK (quantity_available >= 0),
    UNIQUE(product_id, size_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE,
    FOREIGN KEY (size_id) REFERENCES sizes(size_id) ON DELETE RESTRICT
);

CREATE TABLE orders (
    order_id SERIAL PRIMARY KEY,
    order_date DATE NOT NULL DEFAULT CURRENT_DATE,
    user_id INTEGER NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE RESTRICT
);

CREATE TABLE order_items (
    order_item_id SERIAL PRIMARY KEY,
    order_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    size_id INTEGER NOT NULL,
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    price NUMERIC(10, 2) NOT NULL CHECK (price >= 0),
    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE RESTRICT,
    FOREIGN KEY (size_id) REFERENCES sizes(size_id) ON DELETE RESTRICT
);

INSERT INTO roles (role_id, role_name) VALUES 
(1, 'Администратор'), 
(2, 'Менеджер'), 
(3, 'Авторизованный пользователь');

INSERT INTO users (user_id, last_name, first_name, middle_name, login, role_id) VALUES
(1, 'Иванов', 'Иван', 'Иванович', 'admin1', 1),
(2, 'Петрова', 'Анна', 'Сергеевна', 'manager1', 2),
(3, 'Сидоров', 'Алексей', 'Петрович', 'user1', 3),
(4, 'Кузнецова', 'Елена', 'Владимировна', 'user2', 3);

INSERT INTO sizes (size_id, size_value) VALUES
(1, '36'), (2, '37'), (3, '38'), (4, '39'), (5, '40'), (6, '41'), (7, '42'), (8, '43'), (9, '44');

INSERT INTO products (product_id, category, subcategory, product_name, manufacturer, image_path, description, composition, price) VALUES
(1, 'Обувь', 'Кроссовки', 'Кроссовки Спортивный Стиль', 'СпортОбувь РФ', 'shoes_1.png', 'Легкие дышащие кроссовки для бега.', 'Текстиль, сетка', 4500.00),
(2, 'Обувь', 'Туфли', 'Классические Кожаные Туфли', 'Элегант', 'shoes_2.png', 'Строгие туфли из натуральной кожи.', 'Натуральная кожа', 6200.00),
(3, 'Обувь', 'Ботинки', 'Зимние Ботинки на Меху', 'Снежная Линия', 'picture.png', 'Теплые ботинк с нескользящей подошвой.', 'Кожа, натуральный мех', 7800.00),
(4, 'Обувь', 'Кеды', 'Кеды Городская Классика', 'СтильТрейд', 'shoes_4.png', 'Универсальные кеды на каждый день.', 'Хлопок, каучук', 2900.00);

INSERT INTO stock_items (stock_item_id, product_id, size_id, quantity_available) VALUES
(1, 1, 3, 10), 
(2, 1, 4, 2), 
(3, 2, 5, 15),
(4, 2, 6, 8),
(5, 3, 7, 5),
(6, 3, 8, 1),
(7, 4, 3, 20),
(8, 4, 4, 12);

INSERT INTO orders (order_id, order_date, user_id) VALUES
(1, '2026-09-15', 3),
(2, '2026-10-10', 4),
(3, '2026-10-21', 3);

INSERT INTO order_items (order_item_id, order_id, product_id, size_id, quantity, price) VALUES
(1, 1, 1, 3, 1, 4500.00),
(2, 1, 4, 3, 2, 2900.00),
(3, 2, 2, 5, 1, 6200.00),
(4, 3, 3, 7, 1, 7800.00);
